
[favicon.ico](favicon.ico)

[tree.txt](tree.txt)

[main.js](main.js)

[main.css](main.css)

[no_js.html](no_js.html)

[md_files/home.md](md_files/home.md)

[md_files/about me/links.md](md_files/about%20me/links.md)

[md_files/about me/skills.md](md_files/about%20me/skills.md)

[md_files/portfolio/index.md](md_files/portfolio/index.md)

[md_files/portfolio/books/tick tack toe.md](md_files/portfolio/books/tick%20tack%20toe.md)

[md_files/portfolio/desmos/boids.md](md_files/portfolio/desmos/boids.md)

[md_files/portfolio/desmos/complex numbers.md](md_files/portfolio/desmos/complex%20numbers.md)

[md_files/portfolio/desmos/fragment shader.md](md_files/portfolio/desmos/fragment%20shader.md)

[md_files/portfolio/desmos/galton board.md](md_files/portfolio/desmos/galton%20board.md)

[md_files/portfolio/desmos/oscilloscope.md](md_files/portfolio/desmos/oscilloscope.md)

[md_files/portfolio/desmos/paint tool.md](md_files/portfolio/desmos/paint%20tool.md)

[md_files/portfolio/desmos/pixel art gif.md](md_files/portfolio/desmos/pixel%20art%20gif.md)

[md_files/portfolio/desmos/probability distributions.md](md_files/portfolio/desmos/probability%20distributions.md)

[md_files/portfolio/desmos/raceing sim.md](md_files/portfolio/desmos/raceing%20sim.md)

[md_files/portfolio/desmos/snake game.md](md_files/portfolio/desmos/snake%20game.md)

[md_files/portfolio/esolangs/desmos interpreter.md](md_files/portfolio/esolangs/desmos%20interpreter.md)

[md_files/portfolio/esolangs/docscript.md](md_files/portfolio/esolangs/docscript.md)

[md_files/portfolio/esolangs/FORTRAN I.md](md_files/portfolio/esolangs/FORTRAN%20I.md)

[md_files/portfolio/golf/dino game.md](md_files/portfolio/golf/dino%20game.md)

[md_files/portfolio/golf/donut.md](md_files/portfolio/golf/donut.md)

[md_files/portfolio/golf/go fish.md](md_files/portfolio/golf/go%20fish.md)

[md_files/portfolio/itch.io/bare king.md](md_files/portfolio/itch.io/bare%20king.md)

[md_files/portfolio/itch.io/Casio BASIC scratch.md](md_files/portfolio/itch.io/Casio%20BASIC%20scratch.md)

[md_files/portfolio/itch.io/crossword genorator.md](md_files/portfolio/itch.io/crossword%20genorator.md)

[md_files/portfolio/itch.io/guess the number.md](md_files/portfolio/itch.io/guess%20the%20number.md)

[md_files/portfolio/itch.io/impossible hangman.md](md_files/portfolio/itch.io/impossible%20hangman.md)

[md_files/portfolio/itch.io/mini city.md](md_files/portfolio/itch.io/mini%20city.md)

[md_files/portfolio/itch.io/patience not included.md](md_files/portfolio/itch.io/patience%20not%20included.md)

[md_files/portfolio/itch.io/quantum chess.md](md_files/portfolio/itch.io/quantum%20chess.md)

[md_files/portfolio/itch.io/TOF calculator.md](md_files/portfolio/itch.io/TOF%20calculator.md)

[md_files/portfolio/msc projects/boids.md](md_files/portfolio/msc%20projects/boids.md)

[md_files/portfolio/web/portfolio.md](md_files/portfolio/web/portfolio.md)

[md_files/portfolio/web/short url.md](md_files/portfolio/web/short%20url.md)

[md_files/portfolio/web/superfast re-randomiser.md](md_files/portfolio/web/superfast%20re-randomiser.md)

[md_files/site/cache.md](md_files/site/cache.md)

[md_files/site/credits.md](md_files/site/credits.md)

[md_files/site/resources.md](md_files/site/resources.md)

[md_files/site/website stats.md](md_files/site/website%20stats.md)

[md_files/site/report bug.md](md_files/site/report%20bug.md)
