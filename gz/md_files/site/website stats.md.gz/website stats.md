
![example workflow](https://github.com/ollielynas/md-website/actions/workflows/static.yml/badge.svg)

<script onload="console.log('l0ad')"></script>