<!-- no index -->

<p><a href="https://icons8.com/">icons8</a></p>
<p><a href="https://phosphoricons.com/">phosphor icons</a></p>
<!-- add gif with link https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExODltamU3M2VsN2w3bHdqb3dnbnJ2OWYzaTI1bWN5aDVqZnNnaDgyZSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/xTiTnLmaxrlBHxsMMg/giphy.gif -->

<p><img class="unicorn" onclick="
let elem = document.createElement('style');
elem.innerHTML = '.link:hover, a:hover, .ur-here {background-image: linear-gradient(to left, violet, indigo, blue, green, yellow, orange, red,violet, indigo, blue, green, yellow, orange, red,violet, indigo, blue, green, yellow, orange, red,violet, indigo, blue, green, yellow, orange, red);-webkit-background-clip: text;background-clip: text;background-position-x: 0;color: transparent;animation: move_left 60s;transition: linear 0.2s;}';
document.body.appendChild(elem);
" src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExODltamU3M2VsN2w3bHdqb3dnbnJ2OWYzaTI1bWN5aDVqZnNnaDgyZSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/xTiTnLmaxrlBHxsMMg/giphy.gif"></img></p>
<!-- LAST EDITED 1699415446 LAST EDITED-->