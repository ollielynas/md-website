<h1>Ollie Lynas</h1>
<p>student</p>
<p><br></p>
<!-- ## Other Pages -->

<h3>About Me</h3>
<p><button id = "md_files/about me/skills.md" class="link" onclick = "window.load_md(this.id);">my skills</button></p>
<p><button id = "md_files/about me/links.md" class="link" onclick = "window.load_md(this.id);">contact me</button></p>
<h3>Projects</h3>
<p><button id = "md_files/portfolio/index.md" class="link" onclick = "window.load_md(this.id);">example projects</button></p>