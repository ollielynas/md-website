<!-- no index -->
<style>
h2 {
    font-size: 1.5em;
}
</style>
<h1>Ollie Lynas</h1>
<p>student</p>
<p><br></p>
<div class="info-box">
<h2>about me</h2>
I am a software engineering student based in Auckland. I made this website as a way to keep my all of my projects in one place as well as a way show them off to my friends. 
<br>
<br>
<a id = "md_files/about me/links.md" class="link" onclick = "window.load_md(this.id);">links</a>
</div>
<p><br></p>
<div class="info-box">
<h2> starred projects</h2>
loading starred projects...
</div>

<!-- LAST EDITED 1699414143 LAST EDITED-->