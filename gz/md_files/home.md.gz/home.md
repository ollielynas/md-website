<!-- no index -->
<style>
h2 {
    font-size: 1.5em;
}
</style>
<h1>Ollie Lynas</h1>
<p>student</p>
<p><br></p>
<p><button id = "md_files/portfolio/index.md" class="link" onclick = "window.load_md(this.id);">my projects</button></p>
<p><button id = "md_files/about me/links.md" class="link" onclick = "window.load_md(this.id);">contact me</button></p>