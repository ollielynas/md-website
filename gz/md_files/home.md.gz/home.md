
# Ollie Lynas
student

<br>

<!-- ## Other Pages -->

### About Me
<button id = "md_files/about me/skills.md" class="link" onclick = "load_md(this.id);">my skills</button>

<button id = "md_files/about me/links.md" class="link" onclick = "load_md(this.id);">contact me</button>

### Projects
<button id = "md_files/portfolio/index.md" class="link" onclick = "load_md(this.id);">example projects</button>
