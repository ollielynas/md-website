<h2>Projects</h2>
<div class="info-box">
<h2>most downloads (as of writing)</h2>
<ul>
<li><a id = "md_files/portfolio/books/tic tac toe.md" class="link" onclick = "window.load_md(this.id);">tic tac toe</a></li>
a pick your own adventure style book that lets you play tic tac toe.
<li><a id = "md_files/portfolio/itch.io/mini city.md" class="link" onclick = "window.load_md(this.id);">mini city</a></li>
a pick your own adventure style book that lets you play tic tac toe. 
<li><a id = "md_files/portfolio/itch.io/patience not included.md" class="link" onclick = "window.load_md(this.id);">patience not included</a></li>
A movement based game with infinite randomly generated levels with increasing difficulty (but all technically possible)
</ul>
</div>
<p><br></p>
<div class="info-box">
<h2> starred projects</h2>
loading starred projects...
</div>
<p><br></p>