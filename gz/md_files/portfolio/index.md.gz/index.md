<h2>Projects</h2>
<h3>High Performance Software</h3>
<p><button id = "md_files/portfolio/web/superfast re-randomiser.md" class="link" onclick = "load_md(this.id);">re-randomiser</button></p>
<p>This is a web based piece of software that can be used to calculate the likelihood that a correlation between two sets of data has occurred randomly. this is done by randomly relocating groups. The more times this is done the more accurate the result will be. </p>
<p><br></p>
<p><button id = "md_files/portfolio/msc projects/boids.md" class="link" onclick = "load_md(this.id);">boids</button></p>
<p>A Boid simulation. Tested running on up to 100,000 boids. </p>
<h3>Most Popular</h3>
<p><button id = "md_files/portfolio/books/tick tack toe.md" class="link" onclick = "load_md(this.id);">tick tack toe</button></p>
<p>A book that you can play tick tack toe against!</p>
<h3>Personal Favorites</h3>
<p><button id = "md_files/portfolio/itch.io/quantum chess.md" class="link" onclick = "load_md(this.id);">quantum chess</button></p>
<p>Chess, but with more luck</p>
<p><br></p>
<p><button id = "md_files/portfolio/esolangs/desmos interpreter.md" class="link" onclick = "load_md(this.id);">turing complete desmos graph</button></p>
<p>A turing complete interpreter for a bf-like programming language implemented in desmos.</p>