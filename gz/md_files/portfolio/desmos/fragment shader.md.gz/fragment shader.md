<h2>Fragment shader</h2>
<p><a href="https://www.desmos.com/calculator/gfskxwtzjs">link</a></p>
<iframe src="https://www.desmos.com/calculator/fofydrkkvz" width="700" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>