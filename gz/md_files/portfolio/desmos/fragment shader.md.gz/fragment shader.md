<h2>Fragment shader</h2>
<!-- A full fragment shader made in desmos -->

<p>This graph simulates a fragment shader. It can display the full 0-255 color range for red green and blue. Includes uniforms for time, mouse position, and resolution.</p>
<p><br></p>
<p><a href="https://www.desmos.com/calculator/omismxpptv">link</a></p>
<p><br></p>
<p><a href="https://www.desmos.com/calculator/kbp1zl0hfr">another example</a></p>
<iframe src="https://www.desmos.com/calculator/omismxpptv" width="700" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>