<h2>Oscilloscope</h2>
<!-- META A two channel oscilloscope made in desmos. META -->

<p>A two channel oscilloscope made in desmos. Inverted contrast recommended.</p>
<iframe src="https://www.desmos.com/calculator/vfdbswn2wc?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>
<!-- LAST EDITED 1700392251 LAST EDITED-->