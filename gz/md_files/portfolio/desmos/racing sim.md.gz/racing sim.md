<!-- META 3D car simulation made in desmos META -->
<h2>Racing Simulation</h2>
<p>3D racing simulator.</p>
<p>To turn left run this function:
$$L_{eftTurn}=\ w_{heel}\ \to\ \max\left(w_{heel}\ -\ 0.7,-\frac{\pi}{6}\right)$$</p>
<p>To turn right 
$$R_{ightTurn}=w_{heel}\to\min\left(w_{heel}\ +\ 0.7,\frac{\pi}{6}\right)$$</p>
<p><a href="https://www.desmos.com/3d/607e4e946d">link</a>
<br></p>
<iframe src="https://www.desmos.com/3d/607e4e946d" title = "desmos racing sim" height="500" width="600"></iframe>

<!-- LAST EDITED 1699416108 LAST EDITED-->