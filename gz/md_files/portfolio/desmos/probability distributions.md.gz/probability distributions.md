<h2>probability distributions</h2>
<p>In order to input your own data you will need to open in Desmos</p>
<h3>how to use</h3>
<p>takes data input in the for of a list fo values</p>
<p>can calculate normal, triangular, and rectangular prediction models based on the data provided</p>
<p>click <em>find best distro</em> to find the best model to fit your data</p>
<iframe src="https://www.desmos.com/calculator/acydcvlec3?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>