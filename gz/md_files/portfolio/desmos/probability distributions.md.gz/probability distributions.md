## probability distributions

In order to input your own data you will need to open in Desmos

### how to use

takes data input in the for of a list fo values

can calculate normal, triangular, and rectangular prediction models based on the data provided

click *find best distro* to find the best model to fit your data

<iframe src="https://www.desmos.com/calculator/acydcvlec3?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>