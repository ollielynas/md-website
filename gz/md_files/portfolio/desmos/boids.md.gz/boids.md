<h2>Boids</h2>
<!-- META a boid simulation made entirely within desmos META -->
<p>The boids follow each other and this causes them to demonstrate a sort of flocking behavior. In this example the boids are also attracted towards the center of the graph. This prevents them from flying out of view. </p>
<p>The following variables can be changed to influence behavior:</p>
<ul>
<li>Attraction, <em>a multiplier for the attractive forces between boids</em></li>
</ul>
<p>$$p_{ull}\left(a\right)\ =\ n_{orm}\left(b_{rb}\left[d_{is}\left(a,b_{rb}\right)&lt;10\right]-a,1\right)$$</p>
<ul>
<li>
<p>Inertia, <em>a multiplier for the inertia of the boids</em></p>
</li>
<li>
<p>CenterAttraction, <em>how much the boids are attracted to the center of the graph</em></p>
</li>
<li>
<p>Speed <em>how fast the boids move</em></p>
</li>
<li>
<p>Repulsion <em>how much the boids are repelled away from each other</em></p>
</li>
</ul>
<p>$$r_{epell}\left(a\right)\ =\frac{n_{orm}\left(a-b_{rb}\left[d_{is}\left(a,b_{rb}\right)&lt;5\right],1\right)}{1.2}$$</p>
<ul>
<li>
<p>Randomness <em>how much random variation is in the boids movement</em></p>
</li>
<li>
<p>Follow <em>how much the boids follow each other</em></p>
</li>
</ul>
<iframe src="https://www.desmos.com/calculator/xbiv9gh80l?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>
<!-- LAST EDITED 1699414290 LAST EDITED-->