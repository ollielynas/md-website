<h2>Pixel Art Gif Editor</h2>
<!-- META Draw two color pixel art and animate it as a gif, entirely in desmos META -->

<p>Each pixel is represented by a single number. The bits of the number represent if the pixel is on or off at any given time. </p>
<iframe src="https://www.desmos.com/calculator/dbtzerxxvx?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>
<!-- LAST EDITED 1700532117 LAST EDITED-->