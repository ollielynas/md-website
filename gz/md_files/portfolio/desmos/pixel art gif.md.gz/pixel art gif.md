<h2>Pixel art gif editor</h2>
<iframe src="https://www.desmos.com/calculator/dbtzerxxvx?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>