<h2>Paint tool</h2>
<iframe src="https://www.desmos.com/calculator/ffcy8cspju?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>