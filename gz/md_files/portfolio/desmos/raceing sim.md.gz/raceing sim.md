
## Racing Simulation

[link](https://www.desmos.com/3d/607e4e946d)

<iframe src="https://www.desmos.com/3d/607e4e946d" title = "desmos racing sim" height="500" width="600"></iframe>
