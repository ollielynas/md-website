<h2>Complex number calculator</h2>
<!-- META a complex number calculator made in desmos META -->

<p>Allows you to add, subtract, multiply, and divide. You can also store your results in a memory buffer and then copy from the buffer into the equation.</p>
<iframe src="https://www.desmos.com/calculator/fjkc1nxwjq?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>
<!-- LAST EDITED 1699426848 LAST EDITED-->