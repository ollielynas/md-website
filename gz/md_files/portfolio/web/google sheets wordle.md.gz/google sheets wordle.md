<h2>Wordle</h2>
<p>wordle implemented using google sheets and google forms. the google sheet &amp; form are shared between all players. every 7th submission will clear the wordle and generate a new word. </p>
<p>to make a guess submit your word using the google sheet below</p>
<iframe src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSpAT4hBW0kE90w3v0md72UiWgF0_7AeCHTmhaBVoDptkd0_vd3utMjad0786ugxZTS8mmNzRREMqff/pubhtml?gid=367259484&amp;single=true&amp;widget=true&amp;" height="240" width="100%"></iframe>

<p><br></p>
<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeT9-owRH8ygfzdOOtc9s4rroqqnueQ72HEjxs0Rru-DGCiBA/viewform?embedded=true" frameborder="0" marginheight="0" marginwidth="0" height="600" width= "100%">Loading…</iframe>