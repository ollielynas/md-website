<h2>Wordle</h2>
<!-- META the game Wordle made using only a mixture of google forms and google sheets META -->

<p>This project is a recreation of <a href="https://www.nytimes.com/games/wordle/index.html">Wordle</a> implemented using google sheets and google forms. the google sheet &amp; form are shared between all players. every 7th submission will clear the wordle and generate a new word.</p>
<p>to make a guess submit your word using the google sheet below</p>
<p>you should not need to click "refresh google sheet" each time you submit however if nothing happens after a couple of seconds you should try clicking the button.</p>
<p>sometimes the google sheet formatting breaks and you need to manually refresh untill it sortes itself out. I have no idea why it behaves like that, something to do with race conditions I think. </p>
<p><button onclick="var iframe = document.getElementById('FrameID');iframe.src = iframe.src;">refresh google sheet</button></p>
<iframe id="FrameID" src="https://docs.google.com/spreadsheets/d/17LzKFD14EYlp2zvq8MLdOLiphvNO0tBZoIDnXPQyrPE/htmlembed/sheet?gid=367259484" height="240" width="100%"></iframe>

<p><br></p>
<iframe onload="var monitor = setInterval(function(){
    var elem = document.activeElement;
    if(elem && elem.tagName == 'IFRAME'){
        clearInterval(monitor);
        setTimeout(
    function() {
        var iframe = document.getElementById('FrameID');
        iframe.src = iframe.src;
    }, 1000);
}
}, 100);" src="https://docs.google.com/forms/d/e/1FAIpQLSeT9-owRH8ygfzdOOtc9s4rroqqnueQ72HEjxs0Rru-DGCiBA/viewform?embedded=true" frameborder="0" marginheight="0" marginwidth="0" height="600" width= "100%">Loading…</iframe>

<p><a href="https://docs.google.com/spreadsheets/d/17LzKFD14EYlp2zvq8MLdOLiphvNO0tBZoIDnXPQyrPE/edit#gid=764618375">sheet link</a>
<a href="https://forms.gle/MRBL5jvXSpsMi4Ad8">form link</a></p>