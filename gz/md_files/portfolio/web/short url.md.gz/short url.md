<!-- no index -->

<h2>Static URL compressor</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/short_url" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/short_url" /></p>
<p>input your url</p>
<p>input: https://stackoverflow.com/questions/11828270/how-do-i-exit-vim</p>
<p>output: https://ollielynas.github.io/short_url/?i=ct11828270</p>
<p><a href="https://ollielynas.github.io/short_url/?i=ct11828270">final result</a>
<small><small>[compressor domain]/?[{code}={compressed url info}]</small></small></p>