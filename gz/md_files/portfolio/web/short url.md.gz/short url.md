<!--META A static url shortener that uses string compression to generate shorter redirect links META -->

<h2>Static URL compressor</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/short_url" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/short_url" /></p>
<p>This website uses string compression to generate a compressed version of your url. This is then added as a variable to the end of the root of this site: <strong>{https://ollielynas.github.io/short_url/?p=}+{Compressed URL}</strong>. </p>
<p>Sometimes this results in a shorter overall url. This would me much more effective if I owned the rights to a shorter domain: e.g.</p>
<p><strong>{https://short.io/?p=}+{Compressed URL}</strong></p>
<p><br></p>
<p>input URL: <a href="https://stackoverflow.com/questions/11828270/how-do-i-exit-vim">https://stackoverflow.com/questions/11828270/how-do-i-exit-vim</a>
<br></p>
<p>output URL: <a href="https://ollielynas.github.io/short_url/?i=ct11828270">https://ollielynas.github.io/short_url/?i=ct11828270</a>
<br></p>
<p><small><small>[compressor domain]/?[{code}={compressed url info}]</small></small></p>
<!-- LAST EDITED Wed Nov  8 14:40:19 2023 LAST EDITED-->