## Static URL compressor

![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/short_url)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/short_url)


input your url


`https://stackoverflow.com/questions/11828270/how-do-i-exit-vim`

  ↓ 
| [url compressor](https://ollielynas.github.io/short_url) |
|----------------|

 ↓
 
 `https://ollielynas.github.io/short_url/?i=ct11828270`


<small><small>[compressor domain]/?[{code}={compressed url info}]</small></small>


[final result](https://ollielynas.github.io/short_url/?i=ct11828270)