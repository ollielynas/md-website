<h2>100% CSS Duck Hunt Game</h2>
<!-- META retro duck hunter game recreated using nothing but CSS and HTML META -->

<p>A recreation (at least in spirit) of the 1984 game <a href="https://en.wikipedia.org/wiki/Duck_Hunt">duck hunt</a>.</p>
<p>clicking the rerun button will allow you to play again.</p>
<p><br></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="bird shooter" src="https://codepen.io/ollielynas/embed/VwgzqXR?default-tab=result&theme-id=light" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/ollielynas/pen/VwgzqXR">
  bird shooter</a> by ollielynas (<a href="https://codepen.io/ollielynas">@ollielynas</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
<!-- LAST EDITED 1700522411 LAST EDITED-->