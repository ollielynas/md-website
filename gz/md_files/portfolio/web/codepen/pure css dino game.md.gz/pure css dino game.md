<h3>100% CSS dinosaur game</h3>
<!-- META a version of the chrome dinosaur game implemented using only css and html META -->
<!-- STAR ICON -->

<p><em>fun fact, css is turing complete</em></p>
<p><br></p>
<p>This version of the chrome dinosaur game is implemented using nothing but css. It works on all browsers and does not require javascript in order to be played. You can text this by disabling js on this page. </p>
<p>feel free to use this as your "js is disabled" popup</p>
<p><br></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Pure CSS dinosaur game" src="https://codepen.io/ollielynas/embed/KKJgBNo?default-tab=result&theme-id=light" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/ollielynas/pen/KKJgBNo">
  Untitled</a> by ollielynas (<a href="https://codepen.io/ollielynas">@ollielynas</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
<!-- LAST EDITED 1699413547 LAST EDITED-->