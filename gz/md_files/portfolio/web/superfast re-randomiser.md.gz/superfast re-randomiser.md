## Re-randomizer

![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/re-rando)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/re-rando)

(written in rust but compiles to wasm+js)

about 500k rerandomisations per second on a list of around 60 items

as high as 12M per second on a list of 2 items

<br>

[try it out!](https://ollielynas.github.io/re-rando/)

[Github](https://github.com/ollielynas/re-rando)

![screenshot](md_files/portfolio/web/Screenshot%202023-09-13%20204225.png)
