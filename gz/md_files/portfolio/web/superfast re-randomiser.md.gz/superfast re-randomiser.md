<h2>Re-randomizer</h2>
<!-- STAR ICON -->
<!-- META a web based program that re-randomizes grouped data to estimate the probability of completely random correlation  META -->
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/re-rando" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/re-rando" /></p>
<p>(written in rust but compiles to wasm+js)</p>
<p>about 500k rerandomisations per second on a list of around 60 items</p>
<p>as high as 12M per second on a list of 2 items</p>
<p>the calculated probabilities are cumulative, so each time the randomization function is run the calculated numbers become more accurate.</p>
<p><br></p>
<p><a href="https://ollielynas.github.io/re-rando/">try it out!</a></p>
<p><a href="https://github.com/ollielynas/re-rando">Github</a></p>
<p><img alt="screenshot" src="md_files/portfolio/web/Screenshot%202023-09-13%20204225.png" /></p>
<!-- LAST EDITED 1699414290 LAST EDITED-->