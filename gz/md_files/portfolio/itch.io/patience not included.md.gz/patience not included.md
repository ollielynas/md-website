## Patience Not Included

<!-- ![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/password-game-clone)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/password-game-clone) -->


<iframe src="https://www.youtube-nocookie.com/embed/eBuAl-20lqg?start=96&modestbranding=1&rel=0&cc_load_policy=1&iv_load_policy=3&fs=0" width="560" height="295" title="not included gameplay" frameborder="0"></iframe>

<iframe frameborder="0" src="https://itch.io/embed/1964135" width="552" height="167"><a href="https://ollie-lynas.itch.io/patience-not-included">Patience Not Included by Ollie lynas</a></iframe>