<h2>bare king</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/Chess" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/Chess" /></p>
<p>turn based, chess themed, rougelike, survival game</p>
<iframe frameborder="0" src="https://itch.io/embed/1964289?linkback=true&amp;border_color=4f3f3f" width="552" height="167"><a href="https://ollie-lynas.itch.io/bare-king">Bare King by Ollie lynas</a></iframe>