<h2>bare king</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/Chess" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/Chess" /></p>
<!-- STAR ICON -->

<!-- META A turn based, chess themed, rougelike, survival game made with rust META -->
<p>turn based, chess themed, rougelike, survival game</p>
<p>you play as the king on a 16x16 grid. White chess pieces appear on the edges of the board. Each third move you make the white pieces make a single move. The game ends when one of the white pieces successfully takes your king. 
You can equip 5 different abilities. The abilities cost energy to use. You can gain energy by taking other pieces. </p>
<p>You get points relative to the value of the pieces that you take. If you take more than one piece at a time (using an ability) you get a point multiplier. As the game progresses the number, and difficulty of the enemy pieces increases. </p>
<iframe frameborder="0" src="https://itch.io/embed/1964289?linkback=true&amp;border_color=4f3f3f" width="552" height="167"><a href="https://ollie-lynas.itch.io/bare-king">Bare King by Ollie lynas</a></iframe>
<!-- LAST EDITED Wed Nov  8 14:36:38 2023 LAST EDITED-->