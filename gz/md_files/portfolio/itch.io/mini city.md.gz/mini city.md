<h2>Mini City</h2>
<!-- META A minimalist city builder game META -->
<!-- STAR ICON -->

<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/minimalist_city_builder" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/minimalist_city_builder" /></p>
<p>This is a small game that I made as a school project. It is inspired by games like factorio but is focused on the idea of complex patterns and behaviors developing from simple rules. </p>
<p><img alt="screenshot" src="https://img.itch.zone/aW1hZ2UvMjA3NTM1MS8xMjYyNTI2OS5wbmc=/original/TYhho4.png" /></p>
<iframe frameborder="0" src="https://itch.io/embed/2075351" width="552" height="167"><a href="https://ollie-lynas.itch.io/minimalistautomationcitybuilder">Mini City by Ollie lynas</a></iframe>