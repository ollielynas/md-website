<h2>Guess the number</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/password-game-clone" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/password-game-clone" /></p>
<p>inspired by that one password game thing</p>
<iframe src="https://ollielynas.github.io/password-game-clone/" width="100%" height="700px" frameborder="0"></iframe>

<iframe frameborder="0" src="https://itch.io/embed/2140014" width="552" height="167"><a href="https://ollie-lynas.itch.io/guess-the-number">Guess The Number by Ollie lynas</a></iframe>