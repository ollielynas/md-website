## Guess the number

![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/password-game-clone)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/password-game-clone)


inspired by that one password game thing

<iframe src="https://ollielynas.github.io/password-game-clone/" width="100%" height="700px" frameborder="0"></iframe>

<iframe frameborder="0" src="https://itch.io/embed/2140014" width="552" height="167"><a href="https://ollie-lynas.itch.io/guess-the-number">Guess The Number by Ollie lynas</a></iframe>