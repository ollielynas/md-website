<h2>Guess the number</h2>
<!-- META A number guessing game inspired by The Password Game META -->
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/password-game-clone" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/password-game-clone" /></p>
<p>Inspired by <a href="https://neal.fun/password-game/">The Password Game</a>. 
This game has room for improvement. Specifically the rules; being a mutable of x, and not including the numbers [a, b, c].</p>
<p>there is also a <a href="https://addons.mozilla.org/en-US/firefox/addon/olynas-number-game-solver/?utm_source=addons.mozilla.org&amp;utm_medium=referral&amp;utm_content=search">firefox extension</a> that can solve the game in milliseconds. </p>
<iframe src="https://ollielynas.github.io/password-game-clone/" width="100%" height="700px" frameborder="0"></iframe>

<iframe frameborder="0" src="https://itch.io/embed/2140014" width="552" height="167"><a href="https://ollie-lynas.itch.io/guess-the-number">Guess The Number by Ollie lynas</a></iframe>
<!-- LAST EDITED Wed Nov  8 14:36:38 2023 LAST EDITED-->