## Casio BASIC visual editor

![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/casio-basic-visual-editor)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/casio-basic-visual-editor)


![editor screenshot](https://img.itch.zone/aW1hZ2UvMjA3NjIzNS8xMjIxMjcyMS5wbmc=/794x1000/qdV9yq.png)

<iframe frameborder="0" src="https://itch.io/embed/2076235?linkback=true" width="552" height="167"><a href="https://ollie-lynas.itch.io/casio-basic-visual">Casio BASIC visual editor by Ollie lynas</a></iframe>