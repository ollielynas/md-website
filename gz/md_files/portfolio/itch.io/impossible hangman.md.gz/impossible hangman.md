<h2>Impossible Hangman</h2>
<!-- META A version of hangman in which your opponent cheats. Who knew hangman could be a rage game?META -->

<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/hangman_egui" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/hangman_egui" /></p>
<p><strong>Who knew hangman could be a rage game?</strong></p>
<p>A version of hangman in which your opponent cheats.</p>
<iframe src="https://ollielynas.github.io/hangman_egui/" width="100%" height="300px"></iframe>

<iframe frameborder="0" src="https://itch.io/embed/2089623" width="552" height="167"><a href="https://ollie-lynas.itch.io/impossible-hangman">Impossible Hangman by Ollie lynas</a></iframe>

<p><br>
<br></p>
<p><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></p>
<style>
    .rating {
        display: flex;
        flex-direction: column;
        border: gray 1px solid;
        border-radius: 1em;
        padding: 0.3em;
        width: fit-content;
    }
    .rating2 {
        display: flex;
        flex-direction: row;
    }
</style>

<div class="rating">
<div class="rating2">
<!-- This is a joke google plz don't tank my search ranking -->
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
<p> 0/5</p>
</div>
<p>very rage inducing</p>
<p>- lots of people</p>
</div>
<!-- LAST EDITED 1700444242 LAST EDITED-->