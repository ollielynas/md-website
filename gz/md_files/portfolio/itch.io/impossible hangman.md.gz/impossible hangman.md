<h2>Impossible hangman</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/hangman_egui" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/hangman_egui" /></p>
<iframe src="https://ollielynas.github.io/hangman_egui/" width="100%" height="300px"></iframe>