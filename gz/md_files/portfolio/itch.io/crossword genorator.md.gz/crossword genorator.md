<h2>Crossword Generator</h2>
<!-- META An online crossword generator. All words are within the top 10000 most common wordsMETA -->

<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/crossword" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/crossword" /></p>
<p>This website generates crosswords using a thesaurus. All of the words are checked against a list of the top 10000 most common words. There are some issues when it is displayed on mobile or is displayed at a low aspect ratio. </p>
<p><strong>works best when played on <a href="https://v6p9d9t4.ssl.hwcdn.net/html/8308172/dist/index.html">itch.io</a></strong></p>
<p><strong>doesn't work on chrome for some reason?</strong></p>
<p><br></p>
<p><a href="https://ollielynas.github.io/crossword/">alt link</a></p>
<p><br></p>
<iframe src="https://v6p9d9t4.ssl.hwcdn.net/html/8308172/dist/index.html" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="200px" width="600px"
style="scale:0.6" allowfullscreen></iframe>

<iframe frameborder="0" src="https://itch.io/embed/2166273" width="552" height="167"><a href="https://ollie-lynas.itch.io/crossword-genorator">Crossword Generator by Ollie lynas</a></iframe>
<!-- LAST EDITED 1700395681 LAST EDITED-->