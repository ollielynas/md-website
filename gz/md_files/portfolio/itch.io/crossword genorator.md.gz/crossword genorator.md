<h2>Crossword Gen</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/crossword" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/crossword" /></p>
<p>This website generates crosswords using a thesaurus. All of the words are checked against a list of the top 10000 most common words. There are some issues when it is displayed on mobile or is displayed at a low aspect ratio. </p>
<p>works better when played on itch.io</p>
<iframe src="https://v6p9d9t4.ssl.hwcdn.net/html/8308172/dist/index.html" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="200px" width="600px"
style="scale:0.6" allowfullscreen></iframe>

<iframe frameborder="0" src="https://itch.io/embed/2166273" width="552" height="167"><a href="https://ollie-lynas.itch.io/crossword-genorator">Crossword Generator by Ollie lynas</a></iframe>