## Quantum chess

![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/quantum_chess)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/quantum_chess)


must be run from within a terminal window in order to work

![quantum chess screenshot](https://img.itch.zone/aW1hZ2UvMTk4ODYwMy8xMjIwNjU4Mi5wbmc=/794x1000/H2xKt7.png)

<iframe frameborder="0" src="https://itch.io/embed/1988603" width="552" height="167"><a href="https://ollie-lynas.itch.io/quantum-chess">Quantum Chess by Ollie lynas</a></iframe>