<h2>Boids</h2>
<!-- META A somewhat optimized boid simulation (tested for up to 100,000 boids) META -->

<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/rust-boid" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/rust-boid" /></p>
<p>up to 20,000 boids running at 60 fps (on my old ass laptop)</p>
<p>can run up to 100,000 boids, though at not such a good framerate. </p>
<p><a href="https://github.com/ollielynas/rust-boid">github</a></p>
<p><img alt="screenshot" src="md_files/portfolio/msc%20projects/boids.png" /></p>
<!-- LAST EDITED 1700392251 LAST EDITED-->