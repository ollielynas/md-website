
## Boids

![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/rust-boid)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/rust-boid)

up to 20,000 boids running at 60 fps (on my old ass laptop)

can run up to 100,000 boids, through at not such a good framerate

[github](https://github.com/ollielynas/rust-boid)

![screenshot](md_files/portfolio/msc%20projects/boids.png)