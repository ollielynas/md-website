<h2>Tic Tac Toe</h2>
<!-- META An unbeatable amalgamation of a pick your own adventure book and the game naughts and crosses META -->

<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/tick-tack-toe-book" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/tick-tack-toe-book" /></p>
<p><a href="https://itch.io/embed-upload/7949497?color=bdf567">read online</a></p>
<p><a href="https://ollie-lynas.itch.io/the-ultimate-guide-to-naughts-and-crosses/purchase">download PDF file</a></p>
<p>Extract from itch.io website:
<br></p>
<p><em>To play read the book/PDF as if it were a pick your own adventure book. To place you move on any valid square turn to page number written on the square. The book will automatically make a move in response and you will be one move closer to losing.</em></p>
<p><br></p>
<iframe frameborder="0" src="https://itch.io/embed/2078262" width="552" height="167"><a href="https://ollie-lynas.itch.io/the-ultimate-guide-to-naughts-and-crosses">The Ultimate Guide To Tic Tac Toe by Ollie lynas</a></iframe>