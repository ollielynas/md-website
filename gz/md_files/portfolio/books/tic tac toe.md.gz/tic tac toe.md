<h2>Tic Tac Toe</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/tick-tack-toe-book" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/tick-tack-toe-book" /></p>
<p><a href="https://itch.io/embed-upload/7949497?color=bdf567">read online</a></p>
<p><a href="https://ollie-lynas.itch.io/the-ultimate-guide-to-naughts-and-crosses/purchase">download PDF file</a></p>
<p>Extract from itch.io website:</p>
<p><em>I mean if you are this desperate to play naughts and crosses just grab any old person off the street. To play simply read the book/PDF as if it were a pick your own adventure book. To place you move on any valid square turn to page number written on the square. The book will automatically make a move in response and you will be one move closer to losing (or tying).</em></p>
<p><em>Note: It may seem like the first two pages are incorrectly labeled. This is because originally this project was a guide  to help me cheat when playing tick tack toe with my friends, the joke being how massively impractical it would be to use, just to win a game of tick tack toe.</em></p>
<iframe frameborder="0" src="https://itch.io/embed/2078262" width="552" height="167"><a href="https://ollie-lynas.itch.io/the-ultimate-guide-to-naughts-and-crosses">The Ultimate Guide To Tic Tac Toe by Ollie lynas</a></iframe>