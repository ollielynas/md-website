<h2>typing speed game</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/BelgianSalamander/word-game" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/BelgianSalamander/word-game" /></p>
<p><br></p>
<p>Made by:</p>
<p><a href="https://github.com/BelgianSalamander">BelgianSalamander</a></p>
<p><a href="https://github.com/ollielynas">Ollie Lynas</a></p>
<p><br></p>
<p>2 player typing speed competition. You are given two lists of words. If you type words from the list on the left they will be added to your opponents right hand list. If your right hand list gets longer than 20 words then you lose. </p>
<p>The game is played through your local network. To play against another person you must be connected to the same network. One person is must chose to be the host. they will determine the ip and port of the game. To run on your local network set the ip to local host and the port to and number. </p>
<p><a href="https://github.com/BelgianSalamander/word-game">GitHub</a></p>
<p><br></p>
<p><br></p>
<p><img alt="screenshot1" src="md_files/portfolio/team%20projects/Screenshot%202023-10-13%20182708.png" /></p>
<p><img alt="screenshot2" src="md_files/portfolio/team%20projects/Screenshot%202023-10-14%20124337.png" /></p>
<p><img alt="screenshot3" src="md_files/portfolio/team%20projects/Screenshot%202023-10-14%20185546.png" /></p>
<!-- LAST EDITED 1699421835 LAST EDITED-->