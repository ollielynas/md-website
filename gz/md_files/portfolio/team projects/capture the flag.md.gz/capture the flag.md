<h2>Capture The Flag</h2>
<p>Made by:</p>
<p><a href="https://github.com/BelgianSalamander">BelgianSalamander</a></p>
<p><a href="https://github.com/ollielynas">Ollie Lynas</a></p>
<p><a href="https://github.com/Sseptimus">Sseptimus</a></p>
<p><br></p>
<p><a href="https://sseptimus.github.io/CTF/">web interface</a></p>
<p><em>The interface seems to be broken at the moment</em></p>
<p><br></p>
<p>This project was inspired by <a href="https://www.youtube.com/@jetlagthegame">Jet Lag:The Game</a>. I was in charge of the web interface. The web interface tracks the position of all of the players and relays this position back to the server. The positions of all of the players and the flags are rendered on a map of the globe. The web interface is also in charge of calculating which pieces of land belong to which teams. All of the data that is sent to te server is sent through https and the server will not send a device data unless they provide a randomly generated password. for security reasons the server host cannot pick the password because I know how bad my friends are at picking passwords. </p>
<p><br></p>
<p>Those are the features that are currently implemented. The plan is to add the ability to tag a person by takeing a picture of them. The web interface allows you to send pictures to any of the people playing. Once they conform that the picture is of them, they will be marked as dead. They will then need to return to their sides in order to respawn. This works on the honor system, however the pictures are kept on the server until the game is over so they can be used to settle disagreements after the fact. This also serves to discourage cheating. </p>
<!-- LAST EDITED 1699413547 LAST EDITED-->