<h2>Turing complete desmos graph</h2>
<!-- META A programming language and interpreter implemented entirely in desmos META -->

<iframe src="https://www.desmos.com/calculator/hrhfrsgzul?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>
<!-- LAST EDITED 1699419097 LAST EDITED-->