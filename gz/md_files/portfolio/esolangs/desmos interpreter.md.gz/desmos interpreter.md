
## Turing complete desmos graph


<iframe src="https://www.desmos.com/calculator/hrhfrsgzul?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>