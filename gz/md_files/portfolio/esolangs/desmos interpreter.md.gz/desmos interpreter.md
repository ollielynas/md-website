<h2>Turing Complete Desmos Graph</h2>
<!-- META A programming language and interpreter implemented entirely in desmos META -->

<p>This project was inspired by the brainfuck programming language. Porgrames for this project are written onto a list that is then fed into the graph. Each command command is represented by a single number.</p>
<iframe src="https://www.desmos.com/calculator/hrhfrsgzul?embed" width="500" height="500" style="border: 1px solid #ccc" frameborder=0></iframe>
<!-- LAST EDITED 1700285585 LAST EDITED-->