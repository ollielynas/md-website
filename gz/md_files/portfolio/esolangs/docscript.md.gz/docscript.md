<h2>GoogleDocs++</h2>
<p>Full (ish) IDE built right in to google docs</p>
<p>designed and built to run docscript</p>
<!-- META A full IDE made in a google doc. META -->
<!-- STAR ICON -->

<p><img alt="screenshot" src="https://ollielynas.github.io/md_files/portfolio/esolangs/Screenshot%202023-09-13%20194709.png" /></p>
<h3>features</h3>
<ul>
<li>Full syntax highting</li>
<li>Breakpoints</li>
<li>Integrated documentation</li>
<li>Supports Docscript (brand new programming language, custom built to run in google docs) and Brainfuck</li>
<li>File edit history (with google docs)</li>
<li>Automatic cloud backups (google drive)</li>
<li>Easy file sharing</li>
<li>Integrated file system</li>
<li>Snippet saver</li>
<li>Spell checking and auto-capitalization (sorry about that)</li>
<li>Code structure outline in the document outline. </li>
<li>ligatures with Fira Code font </li>
</ul>
<iframe src="https://docs.google.com/document/d/e/2PACX-1vSV7saPBxNrxc5NfddK_Uxa4v9kuFU9Qn5a5p8FUDIQNL_5Boi1hMN9Hj1WXcIphCMXhZXhUAq98K38/pub?embedded=true" width= "100%" height="700px"></iframe>
<!-- LAST EDITED 1700444000 LAST EDITED-->