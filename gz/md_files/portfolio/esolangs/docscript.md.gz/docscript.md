## GoogleDocs++
Full (ish) IDE built right in to google docs

designed and built to run docscript

![screenshot](md_files/portfolio/esolangs/Screenshot%202023-09-13%20194709.png)


### features
 - Full syntax highting
 - Breakpoints
 - Integrated documentation
 - Supports Docscript (brand new programming language, custom built to run in google docs) and Brainfuck
 - File edit history (with google docs)
 - Automatic cloud backups (google drive)
 - Easy file sharing
 - Integrated file system
 - Snippet saver
 - Spell checking and auto-capitalization (sorry about that)

<iframe src="https://docs.google.com/document/d/e/2PACX-1vSV7saPBxNrxc5NfddK_Uxa4v9kuFU9Qn5a5p8FUDIQNL_5Boi1hMN9Hj1WXcIphCMXhZXhUAq98K38/pub?embedded=true" width= "100%" height="700px"></iframe>