<h2>FORTRAN 1</h2>
<p><img alt="GitHub top language" src="https://img.shields.io/github/languages/top/ollielynas/Fortran-1" />
<img alt="GitHub code size in bytes" src="https://img.shields.io/github/languages/code-size/ollielynas/Fortran-1" /></p>
<!-- META A fortran 1 interpreter based on the original documentation from 1956 META -->
<!-- STAR ICON -->

<p><small><em>yeh I consider it exoteric</em></small></p>
<p>this project is unfinished as I still have several features to implement</p>
<p><img alt="screenshot" src="md_files/portfolio/esolangs/Screenshot%202023-09-13%20200839.png" /></p>
<h3>links</h3>
<p><a href="https://ollielynas.github.io/Fortran-1/">try it out</a></p>
<p><a href="https://archive.computerhistory.org/resources/text/Fortran/102649787.05.01.acc.pdf">based on this documentation</a></p>
<p><a href="https://github.com/ollielynas/Fortran-1">Github</a></p>
<!-- LAST EDITED Wed Nov  8 14:40:18 2023 LAST EDITED-->