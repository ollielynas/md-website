## FORTRAN 1
![GitHub top language](https://img.shields.io/github/languages/top/ollielynas/Fortran-1)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ollielynas/Fortran-1)



<small>*yeh I consider it exoteric*</small>

this project is unfinished as I still have several features to implement

![screenshot](md_files/portfolio/esolangs/Screenshot%202023-09-13%20200839.png)

### links

[website](https://ollielynas.github.io/Fortran-1/)

[based on this documentation](https://archive.computerhistory.org/resources/text/Fortran/102649787.05.01.acc.pdf)

[Github](https://github.com/ollielynas/Fortran-1)
