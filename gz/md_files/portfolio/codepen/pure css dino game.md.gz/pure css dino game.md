<h3>100% css dinosaur game</h3>
<!-- META a version of the chrome dinosaur game implemented using only css and html META -->
<p><em>fun fact, css is turing complete</em></p>
<p><br></p>
<p>feel free to use this as your "js is disabled" popup</p>
<p><br></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Untitled" src="https://codepen.io/ollielynas/embed/KKJgBNo?default-tab=result&theme-id=light" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/ollielynas/pen/KKJgBNo">
  Untitled</a> by ollielynas (<a href="https://codepen.io/ollielynas">@ollielynas</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>