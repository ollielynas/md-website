<h2>Haiku</h2>
<!-- META A golfed random Haiku generator made with python META -->

<p>A random Haiku generator made with python.</p>
<pre>
<code class="language-python">
import this,re;a,y,f,*l='',[0],0
while set([5,12,17]+y)!=set(y):
 l+=[w:=(re.sub(r'[^A-Za-z]+',' ',"".join(this.d.get(m,m)for m in this.s)).split(' ')[hash(a:=a+'\n')%40])];y+=[y[-1]+max(len(re.split(r'[aeiouy]+',w)[1:])-(w[-1]=='e'),1)]
 if y[-1]>17:y,*l=[0],
for i in l:a+=i+' \n'[(y[f]in[5,12])];f+=1
print(a)
</code>
</pre>

<h4>example poems:</h4>
<p>*
<em>Special Beautiful</em></p>
<p><em>better than is is complex</em></p>
<p><em>implicit better</em></p>
<p><br></p>
<p><em>is better than than</em></p>
<p><em>ugly ugly Beautiful</em></p>
<p><em>better better Flat</em></p>
<p><br></p>
<p><em>implicit is counts</em></p>
<p><em>dense than than Special Explicit</em></p>
<p><em>is Explicit ugly</em></p>
<p><br></p>
<p><em>better is nested</em></p>
<p><em>Complex Readability</em></p>
<p><em>of Explicit Sparse counts</em></p>
<!-- LAST EDITED 1706180355 LAST EDITED-->