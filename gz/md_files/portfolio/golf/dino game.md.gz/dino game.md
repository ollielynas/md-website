<h1>Dino Game</h1>
<!-- META
import time as q,msvcrt as a;d=t=1;l=' '*20
while' '==l[3]or d:
 d>>=1;t*=.99;print(l[:3]+'🦖^'[d>0]+l[4:],end='\r');l=l[1:]+'🌵 '[hash(t)%9>0];q.sleep(t)
 if a.kbhit()*(d<1):d=9;a.getch() META -->

<p>A golfed version of the chrome dino game that can be played in the terminal
This was made to be able to fit into my discord description</p>
<p>Thanks to <a href="https://github.com/BelgianSalamander">BelgianSalamander</a> for helping</p>
<pre>
<code class="language-python">
import time as q,msvcrt as a;d=t=1;l=' '*20
while' '==l[3]or d:
 d>>=1;t*=.99;print(l[:3]+'🦖^'[d>0]+l[4:],end='\r');l=l[1:]+'🌵 '[hash(t)%9>0];q.sleep(t)
 if a.kbhit()*(d<1):d=9;a.getch()

</code>
</pre>

<p>looks a bit like this:</p>
<pre>
<code class="language-">
C:\User\dino.py>   🦖    🌵🌵      🌵   
</code>
</pre>

<!-- LAST EDITED 1699426139 LAST EDITED-->