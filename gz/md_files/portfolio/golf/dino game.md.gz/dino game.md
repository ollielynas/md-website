<h1>Dino Game</h1>
<p>A golfed version of the chrome dino game that can be played in the terminal</p>
<pre>
<code class="language-python">
import time as q,msvcrt as a;d=t=1;l=' '*20
while' '==l[3]or d:
 d>>=1;t*=.99;print(l[:3]+'ðŸ¦–^'[d>0]+l[4:],end='\r');l=l[1:]+'ðŸŒµ '[hash(t)%9>0];q.sleep(t)
 if a.kbhit()*(d<1):d=9;a.getch()

</code>
</pre>

<p>looks a bit like this:</p>
<pre>
<code class="language-">
C:\User\dino.py>   ðŸ¦–    ðŸŒµðŸŒµ      ðŸŒµ   
</code>
</pre>