<!-- no index -->

<h3>Skills</h3>
<p><br></p>
<p>todo</p>
<p><br></p>
<p><em>todo: become skilled</em></p>
<!-- LAST EDITED 1699426139 LAST EDITED-->