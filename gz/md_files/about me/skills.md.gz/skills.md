<!-- no index -->

<h2>Skills</h2>
<p><br></p>
<p>todo</p>
<p><br></p>
<p><em>todo: become skilled</em></p>
<!-- LAST EDITED 1700522779 LAST EDITED-->