### Skills

<br>

I have none :(

<br>

*todo: become skilled*