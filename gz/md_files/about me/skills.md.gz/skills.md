<!-- no index -->

<h3>Skills</h3>
<p><br></p>
<p>I have none :(</p>
<p><br></p>
<p><em>todo: become skilled</em></p>
<!-- LAST EDITED Wed Nov  8 14:36:37 2023 LAST EDITED-->