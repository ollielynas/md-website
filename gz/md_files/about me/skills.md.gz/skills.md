<!-- no index -->
<h3>Skills<br>I have none :(<br><em>todo: become skilled</em></h3>
<!-- LAST EDITED Wed Nov  8 14:23:42 2023 LAST EDITED-->