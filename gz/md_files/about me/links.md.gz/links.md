<!-- no index -->

<h2>Other Links</h2>
<style>
img[src^="https://img.shields.io"] {
    height: 2.1em;
    width: auto;
    padding: 0;
    margin: 0;
    border: none;
}
</style>

<p><br></p>
<p><a href="https://ollie-lynas.itch.io/"><img alt="Link to Itch.io" src="https://img.shields.io/badge/Itch-%23FF0B34.svg?style=for-the-badge&amp;logo=Itch.io&amp;logoColor=white" /></a></p>
<p><br></p>
<p><a href="https://github.com/ollielynas"><img alt="Link to GitHub" src="https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&amp;logo=github&amp;logoColor=white" /></a></p>
<p><br></p>
<p><a href="mailto:lynasollie@gmail.com"><img alt="Email Me" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&amp;logo=gmail&amp;logoColor=white" /></a></p>
<!-- LAST EDITED 1699414745 LAST EDITED-->