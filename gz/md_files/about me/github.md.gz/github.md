<!-- META A graphical summary of the github activity of Ollie Lynas META -->
<h2><a href="https://github.com/ollielynas">Github</a></h2>
<p><img src="https://myreadme.vercel.app/api/embed/ollielynas?panels=userstatistics,toprepositories,toplanguages,commitgraph" alt="summary of my github activity" onload="document.getElementById('remove-me1').style.color = 'transparent'" /></p>
<p><em><div id = 'remove-me1'>loading stats 1/2...</div></em></p>
<p><img src="https://metrics.lecoq.io/ollielynas?template=classic&base.header=0&gists=1&lines=1&config.timezone=America%2FToronto" alt="some more metrics regarding my github acccount" onload="document.getElementById('remove-me2').style.color = 'transparent'" /></p>
<p><em><div id = 'remove-me2'>loading stats 2/2...</div></em></p>
<!-- LAST EDITED 1699422897 LAST EDITED-->