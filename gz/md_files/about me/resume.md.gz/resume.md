<!-- no index -->

<style>
.md_file {
    overflow: visible;
}
#md_block {
    :not(:is(h1,h2,h3,h4,h5,h6,h7)):not(:last-child):not(.show):not(.show > *) {
        display: none;
    }
    .hide {
        display: none;
    }


    .show > button {
        display:none;
    }

    h1,h2,h3,h4,h5,h6 {
        font-weight: normal;
    }
    padding: 1em;
    background-color: white;
    filter: drop-shadow(0px 10px 3px black);

}
</style>

<h1>Ollie Lynas</h1>
<h5>todo: make look good, this is more of a proof of concept</h5>
<h5>to generate a resume tick the items that you want and click generate</h5>
<h2>Personal Values <input type="checkbox"></input></h2>
<h3>Respect <input type="checkbox"></input></h3>
<p>I respect ppl </p>
<h3>Hard Work <input type="checkbox"></input></h3>
<p>u gotta work hard</p>
<h2>Relevant Experience <input type="checkbox"></input></h2>
<h3>Rust <input type="checkbox"></input></h3>
<p>Rust is one of my favorite languages to use. I have been using it to develop a number fo personal project for several years. These include: </p>
<ul>
<li><a href="/index.html#md_files/portfolio/desmos/raceing sim.md">fortran 1 interpreter</a></li>
<li><a href="/index.html#md_files/portfolio/itch.io/mini city.md">city builder game</a></li>
<li><a href="/index.html#md_files/portfolio/web/superfast re-randomiser.md">web based re-randomizer</a></li>
</ul>
<p>In perticular I enjoyed the <a href="/index.html#md_files/portfolio/web/superfast re-randomiser.md">web based re-randomizer</a> as I spent some time optimizing it to run as fast as possible. </p>
<h3>Python <input type="checkbox"></input></h3>
<p>Python was one of the first languages that I learnt. I have continued to use it to this day, however I mostly use it for </p>
<h3>JavaScript <input type="checkbox"></input></h3>
<p>I have used JS to create a number websites. Most notably is <a href="/index.html#md_files/portfolio/team projects/capture the flag.md">capture the flag</a> which I made with a couple of friends.</p>
<h2>Qualifications <input type="checkbox"></input></h2>
<h2>Prior Work Experience <input type="checkbox"></input></h2>
<h3>TriStar <input type="checkbox"></input></h3>
<p>I have worked at <a href="https://tristar.org.nz/">TriStar</a> as a coach. </p>
<script>
function hashCode(str) {
    let hash = 0;
    for (let i = 0, len = str.length; i < len; i++) {
        let chr = str.charCodeAt(i);
        hash = (hash << 5) - hash + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}
</script>

<p><button onclick = "
md = document.getElementById('md_block');
hide = false;
for (i of md.children) {
    for (l of i.children) {
        if (l.checked == true) {
            hide = false
            l.className='hide'
        }
        if (l.checked == false) {
            hide = true
            l.className='hide'
        }
        if (l.checked == true) {
            hide = false
        }
    }
    if (!hide) {
        i.className='show'
    }else {
        i.className='hide'
    }
};
">generate</button></p>
<!-- LAST EDITED 1699414290 LAST EDITED-->